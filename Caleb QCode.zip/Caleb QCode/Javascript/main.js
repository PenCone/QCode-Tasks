function BucksFizzNo() {
    var table = "<tbody>";

    for (var i = 1; i <= 100; i++) {
        if (i % 5 == 1) {
            table += "<tr>";
        }

        if (i % 3 == 0 && i % 5 == 0) {
            table += "<td>BucksFizz</td>";
        } else if (i % 3 == 0) {
            table += "<td>Bucks</td>";
        } else if (i % 5 == 0) {
            table += "<td>Fizz</td></tr>";
        } else {
            table += "<td>" + i + "</td>";
        }
        
    }

    table += "</tbody>";

    document.getElementById("container").innerHTML = table;
}

function Triangles() {
    var a = parseInt(document.getElementById("sideA").value);
    var b = parseInt(document.getElementById("sideB").value);
    var c = parseInt(document.getElementById("sideC").value);

    if (a != 0 && a == b && b == c) {
        document.getElementById("TriangleType").innerHTML = "Equilateral";
    } else if (((a + b) <= c) || ((a + c) <= b) || ((b + c) <= a)) {
        document.getElementById("TriangleType").innerHTML = "Impossible";
    } else if ((a == b && a != c) || (a == c && a != b) || (b == c && b != a)) {
        document.getElementById("TriangleType").innerHTML = "Isoceles";
    } else if (a != b && a != c && b != c) {
        document.getElementById("TriangleType").innerHTML = "Scalene";
    } else {
        document.getElementById("TriangleType").innerHTML = "Impossible";
    }
    
}
/*
document.getElementById("sideA").addEventListener("input", inputRangeChange("A"));
document.getElementById("sideB").addEventListener("input", inputRangeChange("B"));
document.getElementById("sideC").addEventListener("input", inputRangeChange("C"));
*/

function inputRangeChange(elem) {
    var elemA = document.getElementById("sideA");
    var elemB = document.getElementById("sideB");
    var elemC = document.getElementById("sideC");
    elemA.min = Math.abs(parseInt(elemB.value) - parseInt(elemC.value));
    elemB.min = Math.abs(parseInt(elemA.value) - parseInt(elemC.value));
    elemC.min = Math.abs(parseInt(elemA.value) - parseInt(elemB.value));

    elemA.max = Math.abs(parseInt(elemB.value) + parseInt(elemC.value));
    elemB.max = Math.abs(parseInt(elemA.value) + parseInt(elemC.value));
    elemC.max = Math.abs(parseInt(elemA.value) + parseInt(elemB.value));


    var eh = "Enter a integer above ";
    document.getElementById("ehA").innerText = eh + elemA.min + " and below " + elemA.max;
    document.getElementById("ehB").innerText = eh + elemB.min + " and below " + elemB.max;
    document.getElementById("ehC").innerText = eh + elemC.min + " and below " + elemC.max;


    console.log(elem);

    var valA = parseInt(elemA.value);
    var valB = parseInt(elemB.value);
    var valC = parseInt(elemC.value);

    switch(elem) {
        case "A": 
            if (valA < 1) {
                alert("Ensure the number is greater than 0")
            }
            break;
        case "B":
            if (valB < 1) {
                alert("Ensure the number is greater than 0")
            }
            break;
        case "C":
            if (valC < 1) {
                alert("Ensure the number is greater than 0")
            }
            break;
    }

    Triangles();
}

var numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];
document.getElementById("array").innerHTML = numbers;

function rotateArray() {

    var shift = parseInt(document.getElementById("shift").value);
    var temp = 0, buf = 0;

    if (shift > 0) {
        var count = numbers.length;
        for (var i = 0; i < shift; i++) {
            for (var j = 0; j < count; j++) {
                buf = numbers[j];
                if (j > 0) {
                    numbers[j] = temp;
                }
                temp = buf;
                if ((j+1) == count) {
                    buf = numbers[0]
                    numbers[0] = temp;
                }
            }
        }
    } else if (shift < 0) {
        var count = (numbers.length-1);
        for (var i = 0; i < Math.abs(shift); i++) {
            for (var j = count; j >= 0; j--) {
                buf = numbers[j];
                if (j < count) {
                    numbers[j] = temp;
                }
                temp = buf;
                if (j == 0) {
                    buf = numbers[count]
                    numbers[count] = temp;
                }
            }
        }
    }
    
    document.getElementById("array").innerHTML = numbers;
}
